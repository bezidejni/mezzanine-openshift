"""
Various utility functions used throughout the different Mezzanine apps.
"""
