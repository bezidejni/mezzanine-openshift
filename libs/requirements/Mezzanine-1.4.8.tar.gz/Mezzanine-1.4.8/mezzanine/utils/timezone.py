
from warnings import warn

from django.utils.timezone import now, get_default_timezone, make_aware


warn("mezzanine.utils.timezone is deprecated, use django.utils.timezone")
