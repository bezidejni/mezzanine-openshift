"""
Provides abstract models and admin features used throughout the various
Mezzanine apps.
"""

from mezzanine import __version__
