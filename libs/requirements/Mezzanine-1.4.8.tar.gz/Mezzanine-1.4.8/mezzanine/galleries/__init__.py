"""
Implements a photo gallery content type.
"""

from mezzanine import __version__
